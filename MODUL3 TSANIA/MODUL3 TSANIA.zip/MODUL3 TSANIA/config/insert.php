<?php
require './connector.php';

$nama_mobil = $_POST['nama_mobil'];
$nama_pemilik = $_POST['pemilik_mobil'];
$merk_mobil = $_POST['merk_mobil'];
$tanggal_beli = $_POST['tanggal_beli'];
$deskripsi = $_POST['deskripsi'];
$status_pembayaran = $_POST['status_pembayaran'];
$foto_mobil = $_FILES['gambar']['nama_mobil'];

$target = "../asset/images/";

if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target . $foto_mobil)) {
  $sql = "INSERT INTO showroom_aprilita (nama_mobil, pemilik_mobil, merk_mobil, tanggal_beli, deskripsi, foto_mobil, status_pembayaran) VALUES ('$nama_mobil', '$pemilik_mobil', '$merk_mobil', '$tanggal_beli', '$deskripsi', '$foto_mobil', '$status_pembayaran')";
  if (mysqli_query($connect, $sql)) {
    header("location: ../pages/ListCar-Aprilita.php");
  } else {
    echo "Error";
  }
} else {
  echo "Error";
}
