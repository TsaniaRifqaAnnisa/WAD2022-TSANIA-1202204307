<?php
require './connector.php';

$id = $_GET['id'];

$mysql = "DELETE FROM showroom_aprilita WHERE id_mobil = $id";

if (mysqli_query($connect, $mysql)) {
  header("location: ../pages/ListCar-Aprilita.php?pesan=delete");
} else {
  echo "Error";
}
