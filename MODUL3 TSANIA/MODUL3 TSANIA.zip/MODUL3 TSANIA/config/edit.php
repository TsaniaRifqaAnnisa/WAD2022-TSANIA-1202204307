<?php
require './connector.php';

$id_mobil = $_GET['id'];
$nama_mobil = $_POST['nama_mobil'];
$nama_pemilik = $_POST['pemilik_mobil'];
$merk_mobil = $_POST['merk_mobil'];
$tanggal_beli = $_POST['tanggal_beli'];
$deskripsi = $_POST['desripsik'];
$status_pembayaran = $_POST['status_pembayaran'];
$foto_mobil = $_FILES['gambar']['nama_mobil'];

$target = "../asset/images/";

if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target . $gambar)) {
  $sql = "UPDATE showroom_aprilita SET nama_mobil = '$nama_mobil', pemilik_mobil = '$nama_pemilik', merk_mobil = '$merk_mobil', tanggal_beli = '$tanggal_beli', deskripsi = '$deskripsi', foto_mobil = '$foto_mobil', status_pembayaran = '$status_pembayaran' WHERE id_mobil = $id";
  if (mysqli_query($connection, $sql)) {
    header("location: ../pages/ListCar-Aprilita.php");
  } else {
    echo "Error";
  }
} else {
  echo "Error";
}
