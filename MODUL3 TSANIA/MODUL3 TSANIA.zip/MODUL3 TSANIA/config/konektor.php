<?php
$connect = new mysqli("localhost", "root", "", "showroom_aprilita_table");

if (!$connect) {
  die("Koneksi Error: " . $connect->connect_error);
}
